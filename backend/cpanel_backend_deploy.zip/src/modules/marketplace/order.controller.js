const Order = require('./Order');
const Product = require('./Product');
const asyncHandler = require('../../shared/middleware/asyncHandler');
const { Op } = require('sequelize');

// @desc    Create new order
// @route   POST /api/orders
// @access  Private
exports.addOrderItems = asyncHandler(async (req, res) => {
  const {
    orderItems,
    shippingAddress,
    paymentMethod,
    itemsPrice,
    taxPrice,
    shippingPrice,
    totalPrice
  } = req.body;

  if (orderItems && orderItems.length === 0) {
    res.status(400);
    throw new Error('No order items');
  }

  // Determine vendor from first product (assuming single vendor or primary vendor logic for MVP)
  // Fetch first product to get vendorId
  let vendorId = null;
  if (orderItems[0].product || orderItems[0].productId) {
    try {
      const pId = orderItems[0].product || orderItems[0].productId;
      // We need simple query here
      const p = await Product.findByPk(pId);
      if (p) vendorId = p.vendorId;
    } catch (err) {
      console.error("Error determining vendor:", err);
    }
  }

  const order = await Order.create({
    orderItems,
    userId: req.user.id,
    shippingAddress,
    paymentMethod,
    itemsPrice,
    taxPrice,
    shippingPrice,
    totalPrice,
    vendorId // Save vendorId to allow filtering
  });

  res.status(201).json(order);
});

// @desc    Get order by ID
// @route   GET /api/orders/:id
// @access  Private
exports.getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findByPk(req.params.id, {
    include: [{
      model: require('../identity/User'),
      as: 'user',
      attributes: ['name', 'email']
    }]
  });

  if (order) {
    res.json(order);
  } else {
    res.status(404);
    throw new Error('Order not found');
  }
});

// @desc    Update order to paid
// @route   PUT /api/orders/:id/pay
// @access  Private
exports.updateOrderToPaid = asyncHandler(async (req, res) => {
  const order = await Order.findByPk(req.params.id);

  if (order) {
    order.isPaid = true;
    order.paidAt = Date.now();
    order.paymentResult = {
      id: req.body.id,
      status: req.body.status,
      update_time: req.body.update_time,
      email_address: req.body.payer.email_address
    };

    const updatedOrder = await order.save();
    res.json(updatedOrder);
  } else {
    res.status(404);
    throw new Error('Order not found');
  }
});

// @desc    Update order to delivered
// @route   PUT /api/orders/:id/deliver
// @access  Private/Admin
exports.updateOrderToDelivered = asyncHandler(async (req, res) => {
  const order = await Order.findByPk(req.params.id);

  if (order) {
    order.isDelivered = true;
    order.deliveredAt = Date.now();
    // Also update status
    order.status = 'delivered';

    const updatedOrder = await order.save();
    res.json(updatedOrder);
  } else {
    res.status(404);
    throw new Error('Order not found');
  }
});

// @desc    Get logged in user orders
// @route   GET /api/orders/myorders
// @access  Private
exports.getMyOrders = asyncHandler(async (req, res) => {
  const orders = await Order.findAll({
    where: { userId: req.user.id },
    order: [['createdAt', 'DESC']]
  });
  res.json(orders);
});

// @desc    Get all orders
// @route   GET /api/orders
// @access  Private/Admin
exports.getOrders = asyncHandler(async (req, res) => {
  const orders = await Order.findAll({
    include: [{
      model: require('../identity/User'),
      as: 'user',
      attributes: ['id', 'name']
    }],
    order: [['createdAt', 'DESC']]
  });
  res.json(orders);
});

// @desc    Update order status
// @route   PUT /api/orders/:id/status
// @access  Private/Vendor
exports.updateOrderStatus = asyncHandler(async (req, res) => {
  const order = await Order.findByPk(req.params.id);

  if (order) {
    // Check if user is vendor for any item in the order
    // Since we can't populate inside JSON, we must fetch products manually
    // 1. Extract product IDs
    const productIds = order.orderItems.map(item => item.product || item.productId); // Check structure

    // 2. Fetch products to check vendorId
    const products = await Product.findAll({
      where: { id: productIds },
      attributes: ['id', 'vendorId']
    });

    const isVendor = products.some(p => String(p.vendorId) === String(req.user.id));

    if (req.user.role !== 'admin' && !isVendor) {
      res.status(403);
      throw new Error('Not authorized to update this order');
    }

    order.status = req.body.status || order.status;
    const updatedOrder = await order.save();
    res.json(updatedOrder);
  } else {
    res.status(404);
    throw new Error('Order not found');
  }
});

// @desc    Get vendor orders
// @route   GET /api/orders/vendor-orders
// @access  Private/Vendor
exports.getVendorOrders = asyncHandler(async (req, res) => {
  const orders = await Order.findAll({
    where: { vendorId: req.user.id },
    include: [{
      model: require('../identity/User'),
      as: 'user',
      attributes: ['id', 'name', 'email']
    }],
    order: [['createdAt', 'DESC']]
  });

  res.json(orders);
});