const cron = require('node-cron');
const { fetchExternalNews } = require('./news.service');
const News = require('../../modules/content/News');
const { Op } = require('sequelize');

const startNewsCron = () => {
    console.log('[Cron] News Auto-Fetcher initialized.');

    // Define the sync logic
    const syncNews = async () => {
        console.log('[Cron] Fetching external news...');
        try {
            // Fetch General News (PageSize 10)
            const newsData = await fetchExternalNews({ pageSize: 10 });

            if (newsData.status === 'ok' && newsData.articles.length > 0) {
                console.log(`[Cron] Found ${newsData.articles.length} articles. Processing...`);

                let newCount = 0;
                for (const article of newsData.articles) {
                    // Deduplicate by Title
                    const existing = await News.findOne({
                        where: { title: article.title }
                    });

                    if (!existing) {
                        try {
                            await News.create({
                                title: article.title,
                                excerpt: article.description ? article.description.substring(0, 250) : article.title,
                                content: article.content || article.description || 'Full content pending...',
                                category: 'general',
                                featuredImage: article.urlToImage || 'default-news-image.jpg',
                                author: article.author ? article.author.substring(0, 50) : (article.source?.name || 'NewsAPI'),
                                authorId: 1, // Default Admin ID
                                status: 'published',
                                tags: ['auto-generated', 'news']
                            });
                            newCount++;
                        } catch (err) {
                            console.error(`[Cron] Failed to save article "${article.title}":`, err.message);
                        }
                    }
                }
                console.log(`[Cron] News Sync Complete. Added ${newCount} new articles.`);
            } else {
                console.log('[Cron] No articles found or error in fetch.');
            }
        } catch (error) {
            console.error('[Cron] Error in News Sync:', error.message);
        }
    };

    // Schedule: Every 4 hours
    cron.schedule('0 */4 * * *', syncNews);

    // Initial Run on Startup (Delayed to ensure DB connection)
    setTimeout(() => {
        console.log('[Cron] Triggering initial News Sync...');
        syncNews();
    }, 10000);
};

module.exports = startNewsCron;
