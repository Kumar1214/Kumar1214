const app = require('./server');
module.exports = app;
