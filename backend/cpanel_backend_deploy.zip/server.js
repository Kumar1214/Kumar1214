const fs = require('fs');
const path = require('path');

// DEBUG LOGGING SETUP
const logFile = path.join(__dirname, 'server_debug.log');
const log = (message) => {
    const timestamp = new Date().toISOString();
    const msg = `[${timestamp}] ${message}\n`;
    console.log(message);
    try {
        fs.appendFileSync(logFile, msg);
    } catch {
        // failed to write log
    }
};

// Initialize app variable for export
let app;

// Catch init errors
try {
    log('--- Server Startup Initiated ---');
    log(`Node Version: ${process.version}`);
    log(`Environment: ${process.env.NODE_ENV}`);
    const express = require('express');
    const dotenv = require('dotenv');
    const cors = require('cors');
    const helmet = require('helmet');
    const { connectDB } = require('./src/shared/config/database');
    const { sanitizeData } = require('./src/shared/middleware/security');
    const logger = require('./src/shared/middleware/logger');
    const errorHandler = require('./src/shared/middleware/errorHandler');

    // Load env vars
    dotenv.config();
    log('Environment variables loaded');

    // Initialize Express App
    app = express();

    // ... (rest of the code)

    // Connect to database
    const startServer = async () => {
        try {
            log('Initializing DB Connection...');
            connectDB();
            log('Database connection initiated');
        } catch (err) {
            log(`CRITICAL: Database connection failed: ${err.message}`);
            log(err.stack);
        }
    };

    // startServer(); // Moved to initApp below

    // Logger Middleware
    app.use(logger);

    // Security Middleware
    app.set('trust proxy', true); // Trust all proxies (needed for cPanel/Passenger)
    app.use(helmet());
    app.use(express.json({ limit: '10mb' }));
    app.use(...sanitizeData());

    // Custom Tracking Middleware
    // const tracker = require('./src/shared/middleware/tracker');
    // app.use(tracker);

    // Initialize Cron Jobs
    const startNewsCron = require('./src/shared/services/cron');
    startNewsCron();

    // CORS setup
    // CORS setup
    // CORS setup
    const clientUrl = process.env.CLIENT_URL || '*';
    const allowedOrigins = clientUrl.includes(',')
        ? clientUrl.split(',').map(url => url.trim())
        : [clientUrl.trim()];

    console.log('Allowed Origins:', allowedOrigins); // Debug log for startup

    app.use(cors({
        origin: allowedOrigins,
        credentials: true
    }));

    // Routes
    app.use('/api/shipping', require('./src/modules/marketplace/shipping.routes'));
    app.use('/api/messages', require('./src/modules/communication/message.routes'));
    // app.use('...', ...);
    app.use((req, res, next) => {
        req.setTimeout(20000);
        next();
    });

    // app.use('/api/', apiLimiter); // TEMPORARILY DISABLED due to 429 glitches

    app.get('/', (req, res) => res.send('API is running...'));
    app.get('/api', (req, res) => res.status(200).json({ status: 'ok' }));
    app.get('/health', (req, res) => res.status(200).json({ status: 'ok' }));
    app.get('/api/health', (req, res) => res.status(200).json({ status: 'ok' }));

    // DB Health
    app.get('/api/health/db', async (req, res) => {
        try {
            const { sequelize } = require('./src/shared/config/database');
            await sequelize.authenticate();
            res.status(200).json({ status: 'ok', database: 'connected' });
        } catch (error) {
            res.status(503).json({ error: error.message });
        }
    });

    // Serve static files from configured upload path
    const uploadPath = process.env.FILE_UPLOAD_PATH || './uploads';
    app.use('/uploads', express.static(uploadPath));
    // Also serve 'public/uploads' if different, just in case legacy data exists
    if (uploadPath !== './public/uploads') {
        app.use('/uploads', express.static('./public/uploads'));
    }
    // Also serve basic './uploads' if different, as fallback
    if (uploadPath !== './uploads') {
        app.use('/uploads', express.static('./uploads'));
    }

    // Serve public directory
    app.use(express.static('public'));

    // Load Routes
    try {
        // app.use('/api/settings', require('./src/modules/core/settings.routes')); // Moved down to avoid route conflicts
        app.use('/api/notifications', require('./src/modules/notifications/notification.routes'));
        app.use('/api/storage', require('./src/modules/content/storage.routes'));
        app.use('/api/media', require('./src/modules/content/media.routes'));
        app.use('/api/community', require('./src/modules/content/community.routes'));
        app.use('/api/pages', require('./src/modules/content/pages.routes'));
        app.use('/api/banners', require('./src/modules/content/banners.routes'));
        app.use('/api/news', require('./src/modules/content/news.routes'));
        app.use('/api/v1/content/knowledgebase', require('./src/modules/content/knowledgebase.routes'));
        app.use('/api/products', require('./src/modules/marketplace/products.routes'));
        app.use('/api/orders', require('./src/modules/marketplace/orders.routes'));
        app.use('/api/cart', require('./src/modules/marketplace/cart.routes'));
        app.use('/api/music', require('./src/modules/entertainment/music.routes'));
        app.use('/api/podcasts', require('./src/modules/entertainment/podcasts.routes'));
        app.use('/api/meditation', require('./src/modules/entertainment/meditation.routes'));
        app.use('/api/entertainment', require('./src/modules/entertainment/entertainment.routes'));
        app.use('/api/courses', require('./src/modules/learning/courses.routes'));
        app.use('/api/astrology', require('./src/modules/entertainment/astrology.routes'));
        app.use('/api/exams', require('./src/modules/learning/exams.routes'));
        app.use('/api/quizzes', require('./src/modules/learning/quizzes.routes'));
        app.use('/api/users', require('./src/modules/identity/users.routes'));
        app.use('/api/roles', require('./src/modules/identity/role.routes')); // Added Role Routes
        app.use('/api/v1/auth', require('./src/modules/identity/auth.routes'));
        app.use('/api/v1/wallet', require('./src/modules/identity/wallet.routes'));
        app.use('/api/v1/certificate', require('./src/modules/identity/certificate.routes'));
        app.use('/api/questions', require('./src/modules/learning/questions.routes'));
        app.use('/api/question-banks', require('./src/modules/learning/questionBanks.routes'));
        app.use('/api/analytics', require('./src/modules/core/analytics.routes'));
        app.use('/api/course-categories', require('./src/modules/learning/courseCategories.routes'));
        app.use('/api/gaushalas', require('./src/modules/marketplace/gaushalas.routes'));
        app.use('/api/cows', require('./src/modules/marketplace/cows.routes'));
        app.use('/api/contact', require('./src/modules/marketplace/contact.routes'));
        app.use('/api/admin', require('./src/modules/admin/admin.routes'));

        // Helpers
        app.use('/api/music-genres', require('./src/modules/entertainment/musicGenres.routes'));
        app.use('/api/music-albums', require('./src/modules/entertainment/musicAlbums.routes'));
        app.use('/api/music-moods', require('./src/modules/entertainment/musicMoods.routes'));
        app.use('/api/podcast-categories', require('./src/modules/entertainment/podcastCategories.routes'));
        app.use('/api/podcast-series', require('./src/modules/entertainment/podcastSeries.routes'));
        app.use('/api/podcast-series', require('./src/modules/entertainment/podcastSeries.routes'));
        app.use('/api/meditation-categories', require('./src/modules/entertainment/meditationCategories.routes'));

        // Content Categories
        app.use('/api/news-categories', require('./src/modules/content/newsCategories.routes'));
        app.use('/api/knowledgebase-categories', require('./src/modules/content/knowledgebaseCategories.routes'));

        app.use('/api/feedback', require('./src/modules/communication/feedback.routes')); // Added Feedback Routes

        // Settings & Communication
        app.use('/api/v1/email-templates', require('./src/modules/core/email-template.routes')); // Email Templates (Unique Route)
        // app.use('/api/communication', require('./src/modules/core/email-template.routes')); // Bulk Email (legacy)
        app.use('/api/settings', require('./src/modules/core/settings.routes')); // Generic Settings (Catch-all)
        app.use('/api/settings', require('./src/modules/core/settings.routes')); // Generic Settings (Catch-all)

        log('Routes loaded successfully');
    } catch (err) {
        log(`CRITICAL: Error loading routes: ${err.message}`);
        log(err.stack);
    }

    app.use((req, res) => res.status(404).json({ success: false, message: 'Route not found' }));
    app.use(errorHandler);

    // Start Server Logic
    const initApp = async () => {
        await startServer();

        const PORT = process.env.PORT || 5001; // Force 5001 to match frontend
        log(`Attempting to listen on port ${PORT}...`);

        const _server = app.listen(PORT, () => {
            log(`Server listening on port ${PORT}. Ready to accept connections.`);
        });
    };

    initApp();

    process.on('unhandledRejection', (err) => {
        log(`Unhandled Rejection: ${err.message}`);
        log(err.stack);
    });

    process.on('uncaughtException', (err) => {
        log(`Uncaught Exception: ${err.message}`);
        log(err.stack);
    });

} catch (e) {
    if (log) {
        log(`Startup Crash: ${e.message}`);
        log(e.stack);
    } else {
        console.error(e);
    }
}

module.exports = app;
