// Shim to point to actual location
module.exports = require('../src/shared/config/database');
