import { PayoutWorkflow, PayoutStatus } from './src/services/finance/PayoutWorkflow';

async function testPayoutWorkflow() {
    console.log('🧪 Starting PayoutWorkflow Test...');

    // 1. Initiate Payout
    const payout = await PayoutWorkflow.initiatePayout(1000, 'VENDOR_123');
    console.log(`[Step 1] Initiated: ${payout.id}, Status: ${payout.status}`);

    if (payout.status !== PayoutStatus.PENDING_APPROVAL) {
        throw new Error('Initial status mismatch');
    }

    // 2. Security Approval
    await PayoutWorkflow.approve(payout, 'SECURITY');
    console.log(`[Step 2] Security Approved. Status: ${payout.status}`);
    if (payout.status !== PayoutStatus.APPROVED_SECURITY) {
        throw new Error('Security approval failed status transition');
    }

    // 3. Finance Approval
    await PayoutWorkflow.approve(payout, 'FINANCE');
    console.log(`[Step 3] Finance Approved. Status: ${payout.status}`);
    if (payout.status !== PayoutStatus.APPROVED_FINANCE) {
        throw new Error('Finance approval failed status transition');
    }

    // 4. Admin Final Verification
    await PayoutWorkflow.approve(payout, 'ADMIN');
    console.log(`[Step 4] Admin Approved. Status: ${payout.status}`);

    if (payout.status === PayoutStatus.READY_FOR_PAYOUT) {
        console.log('✅ TEST PASSED: Payout reached READY state through State Machine.');
    } else {
        console.error('❌ TEST FAILED: Payout did not reach READY state.');
    }
}

testPayoutWorkflow().catch(err => console.error(err));
