const { sequelize } = require('../src/shared/config/database');
const User = require('../src/modules/identity/User');
const Role = require('../src/modules/identity/Role');
const VendorProfile = require('../src/modules/marketplace/VendorProfile');
const GaushalaProfile = require('../src/modules/marketplace/GaushalaProfile');
const Astrologer = require('../src/modules/identity/Astrologer');
const Product = require('../src/modules/marketplace/Product');
const Course = require('../src/modules/learning/Course');
const bcrypt = require('bcryptjs');

const seedData = async () => {
    try {
        console.log('[SEED] Connecting to database...');
        await sequelize.authenticate();
        console.log('[SEED] Database connected.');

        // 1. Roles
        const roles = ['admin', 'learner', 'instructor', 'author', 'artist', 'vendor', 'gaushala_owner', 'astrologer'];
        for (const roleName of roles) {
            await Role.findOrCreate({ where: { name: roleName }, defaults: { name: roleName } });
        }
        console.log('[SEED] Roles verified.');

        // 2. Users (One for each role)
        const passwordHash = await bcrypt.hash('Password@123', 10);
        const users = [
            { name: 'Super Admin', email: 'admin@gaugyan.com', role: 'admin' },
            { name: 'John User', email: 'user@gaugyan.com', role: 'user' },
            { name: 'Master Instructor', email: 'instructor@gaugyan.com', role: 'instructor' },
            { name: 'Jane Author', email: 'author@gaugyan.com', role: 'author' },
            { name: 'Picasso Artist', email: 'artist@gaugyan.com', role: 'artist' },
            { name: 'Best Vendor', email: 'vendor@gaugyan.com', role: 'vendor' },
            { name: 'Nandi Gaushala', email: 'owner@gaugyan.com', role: 'gaushala_owner' },
            { name: 'Mystic Astrologer', email: 'astrologer@gaugyan.com', role: 'astrologer' }
        ];

        for (const u of users) {
            const [, created] = await User.findOrCreate({
                where: { email: u.email },
                defaults: {
                    name: u.name,
                    email: u.email,
                    password: passwordHash,
                    role: u.role,
                    isVerified: true
                }
            });
            if (created) console.log(`[SEED] Created user: ${u.email}`);
            else console.log(`[SEED] User exists: ${u.email}`);
        }

        // 3. Vendor Data (10 Products)
        const vendorUser = await User.findOne({ where: { email: 'vendor@gaugyan.com' } });
        if (vendorUser) {
            await VendorProfile.findOrCreate({
                where: { userId: vendorUser.id },
                defaults: {
                    storeName: 'Divine Cow Products',
                    userId: vendorUser.id,
                    storeDescription: 'Authentic cow-based products sourced directly from verified Gaushalas.'
                }
            });

            const products = Array.from({ length: 10 }).map((_, i) => ({
                name: `Organic Cow Product ${i + 1}`,
                slug: `organic-cow-product-${i + 1}`,
                description: 'Pure organic product from indigenous cows.',
                price: 100 + (i * 10),
                vendorId: vendorUser.id,
                stock: 50,
                category: 'Cow Products',
                images: ['https://via.placeholder.com/300']
            }));

            for (const p of products) {
                await Product.findOrCreate({ where: { slug: p.slug }, defaults: p });
            }
            console.log('[SEED] Vendor products seeded.');
        }

        // 4. Instructor Data (5 Courses)
        const instructorUser = await User.findOne({ where: { email: 'instructor@gaugyan.com' } });
        if (instructorUser) {
            const courses = Array.from({ length: 5 }).map((_, i) => ({
                title: `Vedic Wisdom Level ${i + 1}`,
                slug: `vedic-wisdom-level-${i + 1}`,
                description: 'Learn the ancient secrets of cow therapy.',
                instructorId: instructorUser.id,
                price: 500,
                category: 'Vedic Studies'
            }));

            for (const c of courses) {
                await Course.findOrCreate({ where: { slug: c.slug }, defaults: c });
            }
            console.log('[SEED] Instructor courses seeded.');
        }

        // 5. Gaushala Data (10 Cows - Placeholder if Cow model exists, usually linked to GaushalaProfile)
        const ownerUser = await User.findOne({ where: { email: 'owner@gaugyan.com' } });
        if (ownerUser) {
            await GaushalaProfile.findOrCreate({
                where: { ownerId: ownerUser.id },
                defaults: { name: 'Nandi Sanctuary', ownerId: ownerUser.id, location: 'Vrindavan' }
            });
            console.log('[SEED] Gaushala profile seeded.');
        }

        // 6. Astrologer Data
        const astroUser = await User.findOne({ where: { email: 'astrologer@gaugyan.com' } });
        if (astroUser) {
            await Astrologer.findOrCreate({
                where: { userId: astroUser.id },
                defaults: { specialties: ['Vedic', 'Prashna'], experience: 10, userId: astroUser.id }
            });
            console.log('[SEED] Astrologer profile seeded.');
        }

        console.log('[SEED] ✅ Seeding Complete. All roles active.');
        process.exit(0);

    } catch (error) {
        console.error('[SEED] ❌ Seeding Failed:', error);
        process.exit(1);
    }
};

seedData();
