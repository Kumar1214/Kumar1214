// DEPRECATED: MongoDB Seeder has been removed as per Security Remediation
// This legacy script is no longer in use. Please use 'production_seeder.js' or 'seedData.js' for Sequelize.

console.error("❌ ERROR: This MongoDB seeder script has been deprecated and disabled.");
console.error("Please use the SQL/Sequelize seeders.");
process.exit(1);
