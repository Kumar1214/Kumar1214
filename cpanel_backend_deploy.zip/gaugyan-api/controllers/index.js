// Shim for legacy directory structure
module.exports = {};
